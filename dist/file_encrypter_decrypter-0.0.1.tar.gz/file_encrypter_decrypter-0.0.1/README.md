# file_encrypter_decrypter

A simple package to Encrypt & Decrypt files or Entire Folder contents